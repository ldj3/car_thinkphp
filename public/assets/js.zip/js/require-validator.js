define(['validator-core', 'validator-lang'], function (Validator, undefined) {
    return Validator;
});