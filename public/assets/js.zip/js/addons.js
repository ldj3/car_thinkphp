define(['backend'], function (Backend) {
    //修改上传的接口调用
require(['upload'], function (Upload) {
    var _onUploadResponse = Upload.events.onUploadResponse;
    Upload.events.onUploadResponse = function (response) {
        try {
            var ret = JSON.parse(response);
            if (ret.hasOwnProperty("code") && ret.hasOwnProperty("data")) {
                return _onUploadResponse.call(this, response);
            } else if (ret.hasOwnProperty("key") && !ret.hasOwnProperty("err_code")) {
                ret.code = 1;
                ret.data = {
                    url: '/' + ret.key
                };
                return _onUploadResponse.call(this, JSON.stringify(ret));
            }
        } catch (e) {
        }
        return _onUploadResponse.call(this, response);

    };
});
require(['form', 'upload'], function (Form, Upload) {
    var _bindevent = Form.events.bindevent;
    Form.events.bindevent = function (form) {
        _bindevent.apply(this, [form]);
        try {
            //绑定summernote事件
            if ($(".summernote,.editor", form).size() > 0) {
                require(['summernote'], function () {
                    $(".summernote,.editor", form).summernote({
                        height: 250,
                        lang: 'zh-CN',
                        fontNames: [
                            'Arial', 'Arial Black', 'Serif', 'Sans', 'Courier',
                            'Courier New', 'Comic Sans MS', 'Helvetica', 'Impact', 'Lucida Grande',
                            "Open Sans", "Hiragino Sans GB", "Microsoft YaHei",
                            '微软雅黑', '宋体', '黑体', '仿宋', '楷体', '幼圆',
                        ],
                        fontNamesIgnoreCheck: [
                            "Open Sans", "Microsoft YaHei",
                            '微软雅黑', '宋体', '黑体', '仿宋', '楷体', '幼圆'
                        ],
                        dialogsInBody: true,
                        callbacks: {
                            onChange: function (contents) {
                                $(this).val(contents);
                                $(this).trigger('change');
                            },
                            onInit: function () {
                            },
                            onImageUpload: function (files) {
                                var that = this;
                                //依次上传图片
                                for (var i = 0; i < files.length; i++) {
                                    Upload.api.send(files[i], function (data) {
                                        var url = Fast.api.cdnurl(data.url);
                                        $(that).summernote("insertImage", url, 'filename');
                                    });
                                }
                            }
                        }
                    });
                });
            }
        } catch (e) {

        }

    };
});

});